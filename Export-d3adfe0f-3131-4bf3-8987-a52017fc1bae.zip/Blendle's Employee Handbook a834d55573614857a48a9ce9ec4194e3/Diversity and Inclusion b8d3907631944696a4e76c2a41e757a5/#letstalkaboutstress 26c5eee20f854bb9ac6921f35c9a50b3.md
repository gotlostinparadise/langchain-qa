# #letstalkaboutstress

Let’s talk about stress. Too much stress. 

We know this can be a topic.

So let’s get this conversation going. 

[Intro: two things you should know](#letstalkaboutstress%2026c5eee20f854bb9ac6921f35c9a50b3/Intro%20two%20things%20you%20should%20know%201e9d1ead05fd43b786090163a603019f.md)

[What is stress](#letstalkaboutstress%2026c5eee20f854bb9ac6921f35c9a50b3/What%20is%20stress%205d558b6112be46d79ad3a48b6b33eed9.md)

[When is there too much stress?](#letstalkaboutstress%2026c5eee20f854bb9ac6921f35c9a50b3/When%20is%20there%20too%20much%20stress%20c26ecf94fd5840ddad3c9ed521ab283c.md)

[What can I do](#letstalkaboutstress%2026c5eee20f854bb9ac6921f35c9a50b3/What%20can%20I%20do%20de9fe4bbfc404540a042985ed4e7f85b.md)

[What can Blendle do?](#letstalkaboutstress%2026c5eee20f854bb9ac6921f35c9a50b3/What%20can%20Blendle%20do%2031526dcdb7174d7d9e4c2d907efe6f5e.md)

[Good reads](#letstalkaboutstress%2026c5eee20f854bb9ac6921f35c9a50b3/Good%20reads%20e975bced442d483c8c510d54e958444d.md)

Go to **#letstalkaboutstress** on slack to chat about this topic

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).